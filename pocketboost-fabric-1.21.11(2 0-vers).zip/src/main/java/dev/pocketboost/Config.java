package dev.pocketboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public boolean enabled = true;
    public boolean adaptive = true;
    public String preset = "strong";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config inst = new Config();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pocketboost.json");
    }

    public static Config get() { return inst; }

    public Preset preset() { return Preset.byId(preset); }

    public static void load() {
        try {
            if (Files.exists(path())) {
                Config c = GSON.fromJson(Files.readString(path()), Config.class);
                inst = c != null ? c : new Config();
            } else {
                save();
            }
        } catch (Exception e) {
            inst = new Config();
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(inst));
        } catch (IOException ignored) {
        }
    }
}
