package dev.pocketboost;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;

public final class PocketBoostClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Config.load();
        Controller.init();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("pocketboost");

            for (Preset p : Preset.values()) {
                root.then(ClientCommandManager.literal(p.id).executes(ctx -> {
                    Config.get().enabled = true;
                    Config.get().preset = p.id;
                    Config.save();
                    Controller.refresh(ctx.getSource().getClient());
                    return say(ctx, "Режим: " + p.id);
                }));
            }

            root.then(ClientCommandManager.literal("off").executes(ctx -> {
                Config.get().enabled = false;
                Config.save();
                Controller.refresh(ctx.getSource().getClient());
                return say(ctx, "Выключено, настройки возвращены.");
            }));

            root.then(ClientCommandManager.literal("auto").executes(ctx -> {
                Config.get().adaptive = !Config.get().adaptive;
                Config.save();
                return say(ctx, "Авто-подстройка по FPS: " + (Config.get().adaptive ? "вкл" : "выкл"));
            }));

            root.then(ClientCommandManager.literal("status").executes(ctx -> say(ctx, Controller.status())));

            dispatcher.register(root);
        });
    }

    private static int say(CommandContext<FabricClientCommandSource> ctx, String msg) {
        ctx.getSource().sendFeedback(Text.literal("[PocketBoost] " + msg));
        return 1;
    }
}
