package dev.pocketboost;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.particle.ParticlesMode;

/**
 * Применяет пресет при входе в мир, подстраивает дальность прорисовки под FPS
 * и возвращает исходные настройки игрока при выходе из мира.
 */
public final class Controller {
    private static final int CHECK_EVERY_TICKS = 40; // раз в 2 секунды

    private record Saved(int view, int sim, ParticlesMode particles, CloudRenderMode clouds,
                         double entityScale, boolean shadows, int blend,
                         int weather, boolean leaves, boolean ao) {}

    private static Saved saved;
    private static int curView, low, high, ticks;

    private Controller() {}

    public static void init() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() -> refresh(client)));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> client.execute(() -> restore(client)));
        ClientTickEvents.END_CLIENT_TICK.register(Controller::tick);
    }

    /** Применить текущий конфиг (или откатить, если мод выключен). */
    public static void refresh(MinecraftClient c) {
        if (c.world == null) return;
        if (Config.get().enabled) apply(c); else restore(c);
    }

    public static String status() {
        Preset p = Config.get().preset();
        return "мод=" + (Config.get().enabled ? "вкл" : "выкл") + ", режим=" + p.id
                + ", авто=" + (Config.get().adaptive ? "вкл" : "выкл")
                + (saved != null ? ", дальность сейчас=" + curView : "");
    }

    private static void apply(MinecraftClient c) {
        GameOptions o = c.options;
        if (saved == null) {
            saved = new Saved(
                    o.getViewDistance().getValue(), o.getSimulationDistance().getValue(),
                    o.getParticles().getValue(), o.getCloudRenderMode().getValue(),
                    o.getEntityDistanceScaling().getValue(),
                    o.getEntityShadows().getValue(), o.getBiomeBlendRadius().getValue(),
                    o.getWeatherRadius().getValue(), o.getCutoutLeaves().getValue(),
                    o.getAo().getValue());
        }
        Preset p = Config.get().preset();
        curView = Math.min(saved.view(), p.viewCap);
        o.getViewDistance().setValue(curView);
        o.getSimulationDistance().setValue(Math.min(saved.sim(), p.simCap));
        o.getParticles().setValue(p.particles);
        o.getCloudRenderMode().setValue(p.clouds);
        o.getEntityDistanceScaling().setValue(Math.min(saved.entityScale(), p.entityScale));
        o.getEntityShadows().setValue(saved.shadows() && p.shadows);
        o.getBiomeBlendRadius().setValue(Math.min(saved.blend(), p.blend));
        o.getWeatherRadius().setValue(Math.min(saved.weather(), p.weather));
        o.getCutoutLeaves().setValue(saved.leaves() && p.leaves);
        o.getAo().setValue(saved.ao() && p.ao);
        low = high = ticks = 0;
    }

    private static void restore(MinecraftClient c) {
        if (saved == null) return;
        GameOptions o = c.options;
        o.getViewDistance().setValue(saved.view());
        o.getSimulationDistance().setValue(saved.sim());
        o.getParticles().setValue(saved.particles());
        o.getCloudRenderMode().setValue(saved.clouds());
        o.getEntityDistanceScaling().setValue(saved.entityScale());
        o.getEntityShadows().setValue(saved.shadows());
        o.getBiomeBlendRadius().setValue(saved.blend());
        o.getWeatherRadius().setValue(saved.weather());
        o.getCutoutLeaves().setValue(saved.leaves());
        o.getAo().setValue(saved.ao());
        saved = null;
    }

    private static void tick(MinecraftClient c) {
        if (saved == null || c.world == null || !Config.get().adaptive || c.isPaused()) return;
        if (++ticks < CHECK_EVERY_TICKS) return;
        ticks = 0;

        Preset p = Config.get().preset();
        int fps = c.getCurrentFps();
        int cap = Math.min(saved.view(), p.viewCap);

        if (fps < p.fpsTarget) {
            high = 0;
            if (++low >= 2 && curView > p.minView) {          // FPS низкий 4 сек подряд -> -1 чанк
                c.options.getViewDistance().setValue(--curView);
                low = 0;
            }
        } else if (fps > p.fpsTarget * 1.4) {
            low = 0;
            if (++high >= 6 && curView < cap) {               // FPS с запасом 12 сек -> +1 чанк
                c.options.getViewDistance().setValue(++curView);
                high = 0;
            }
        } else {
            low = high = 0;
        }
    }
}
