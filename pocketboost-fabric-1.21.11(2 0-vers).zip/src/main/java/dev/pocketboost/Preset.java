package dev.pocketboost;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.particle.ParticlesMode;

/** Сила оптимизации: STRONG = максимум FPS, WEAK = почти ваниль. */
public enum Preset {
    //      id       view sim minV particles              clouds                 entity shadows blend weather leaves ao    fps
    STRONG("strong",  6,   5,  2,  ParticlesMode.MINIMAL,   CloudRenderMode.OFF,  0.5,  false, 0,   3,  false, false, 30),
    MEDIUM("medium", 10,   8,  4,  ParticlesMode.DECREASED, CloudRenderMode.FAST, 0.75, false, 1,   5,  false, true,  45),
    WEAK  ("weak",   16,  12,  6,  ParticlesMode.ALL,       CloudRenderMode.FAST, 1.0,  true,  2,   8,  true,  true,  60);

    public final String id;
    public final int viewCap, simCap, minView, blend, weather, fpsTarget;
    public final ParticlesMode particles;
    public final CloudRenderMode clouds;
    public final double entityScale;
    public final boolean shadows, leaves, ao;

    Preset(String id, int viewCap, int simCap, int minView, ParticlesMode particles,
           CloudRenderMode clouds, double entityScale, boolean shadows, int blend,
           int weather, boolean leaves, boolean ao, int fpsTarget) {
        this.id = id; this.viewCap = viewCap; this.simCap = simCap; this.minView = minView;
        this.particles = particles; this.clouds = clouds; this.entityScale = entityScale;
        this.shadows = shadows; this.blend = blend; this.weather = weather;
        this.leaves = leaves; this.ao = ao; this.fpsTarget = fpsTarget;
    }

    public static Preset byId(String id) {
        for (Preset p : values()) if (p.id.equalsIgnoreCase(id)) return p;
        return STRONG;
    }
}
