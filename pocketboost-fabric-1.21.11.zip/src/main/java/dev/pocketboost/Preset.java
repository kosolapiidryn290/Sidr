package dev.pocketboost;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Сила оптимизации: STRONG = максимум FPS, WEAK = почти ваниль. */
public enum Preset {
    //     id        viewCap simCap minView particles              clouds                graphics            entityScale shadows blend fpsTarget
    STRONG("strong",   6,     5,     2,   ParticlesMode.MINIMAL,   CloudRenderMode.OFF,  GraphicsMode.FAST,  0.5,  false, 0, 30),
    MEDIUM("medium",  10,     8,     4,   ParticlesMode.DECREASED, CloudRenderMode.FAST, GraphicsMode.FAST,  0.75, false, 1, 45),
    WEAK  ("weak",    16,    12,     6,   ParticlesMode.ALL,       CloudRenderMode.FAST, GraphicsMode.FANCY, 1.0,  true,  2, 60);

    public final String id;
    public final int viewCap, simCap, minView, blend, fpsTarget;
    public final ParticlesMode particles;
    public final CloudRenderMode clouds;
    public final GraphicsMode graphics;
    public final double entityScale;
    public final boolean shadows;

    Preset(String id, int viewCap, int simCap, int minView, ParticlesMode particles,
           CloudRenderMode clouds, GraphicsMode graphics, double entityScale,
           boolean shadows, int blend, int fpsTarget) {
        this.id = id; this.viewCap = viewCap; this.simCap = simCap; this.minView = minView;
        this.particles = particles; this.clouds = clouds; this.graphics = graphics;
        this.entityScale = entityScale; this.shadows = shadows; this.blend = blend;
        this.fpsTarget = fpsTarget;
    }

    public static Preset byId(String id) {
        for (Preset p : values()) if (p.id.equalsIgnoreCase(id)) return p;
        return STRONG;
    }
}
